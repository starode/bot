import telebot
from telebot import types
from telebot.types import InputMediaPhoto

TOKEN = "5084175273:AAHOOcjfBSHrR1oeVSuQ9oJ9_orYgm1ciys"
bot = telebot.TeleBot(TOKEN)


buttons = {"Про AIESEC" : {
                            "Департаменти" : { 
                                                "Outgoing Global Volunteer" : '''Outgoing Global Volunteer

Департамент, що займається пошуком та організацією проєктів для української молоді, яка хоче спробувати себе у волонтерстві за кордоном. Наразі набір проводиться для двох команд: 

1⃣ Considerations teams - дві команди, які займатимуться процесом відбору кандидатів на волонтерські стажування та їхнім досвідом до затвердження людини на конкретний проєкт.

2⃣ Customer experience + International Relations team - команда, яка відповідає за етапи підготовки волонтерів до проєктів, їхній досвід безпосередньо на стажуваннях а також за комунікацію з іншими осередками AIESEC за кордоном.
(На фото віцепрезидентка департаменту Ліля)''' ,
                                                "Outgoing Global Talent" : '''Outgoing Global Talent

Департамент, що займається пошуком та організацією професійних стажувань за кордоном для українців. Набір відбувається до таких команд:

1⃣ Global Talent team - команда, яка відповідає за досвід кандидатів на професійні стажування з моменту подачі до затвердження їхньої кандидатури.

2⃣ Global Teacher team - команда, яка відповідає за досвід кандидатів на стажування для вчителів з моменту подачі до затвердження їхньої кандидатури.

3⃣ Customer experience + International Relations team - яка відповідає за етапи підготовки волонтерів до проєктів, їхній досвід безпосередньо на стажуваннях а також за комунікацію з іншими осередками AIESEC за кордоном.
(На фото віцепрезидентка департаменту Діана)''',
                                                "Incoming Global Volunteer" : '''Incoming Global Volunteer

Департамент, що займається організацією волонтерських стажувань для іноземної молоді у співпраці зі школами, таборами та ГО, а також підтримкою волонтерів під час перебігу проєктів, комунікацією з різними осередками AIESEC за кордоном. У департаменті є чотири команди, до яких проводитиметься набір:

1⃣ Operations teams - дві команди, відповідальні за відбір волонтерів для проєктів у Києві та їхню підтримку протягом стажування.

2⃣ New Sales team - команда, яка займається пошуком стейкхолдерів (шкіл, таборів, громадських організацій) для організації волонтерський стажувань для іноземців в Україні.
3⃣ Account managers team - команда, яка займається підтримкою співпраці з партнерами Global Volunteer (з установами, з якими у нас уже відбувалася співпраця раніше), постійною комунікацією з ними.
(На фото віцепрезидентка департаменту Ангеліна)''' ,
                                                "Incoming Global Talent" : '''Incoming Global Talent

Департамент, що займається організацією професійних стажувань для іноземної молоді в українських компаніях, підтримкою стажерів до, під час, та після стажування, комунікацією з різними осередками AIESEC за кордоном. Департамент проводить набір до чотирьох команд:

1⃣ Operations team - команда, яка займається міжнародною комунікацією з іншими осередками AIESEC, процесом відбору та підготовки стажерів до проєктів.

2⃣ New Sales teams - дві команди, відповідальні за пошук і співпрацю з потенційними роботодавцями для іноземних стажерів.

3⃣ Account managers team - команда, яка займається підтримкою співпраці з партнерами Global Talent (з установами, з якими у нас уже відбувалася співпраця раніше), постійною комунікацією з ними.
(На фото віцепрезидентка департаменту Ася)''' ,
                                                "Marketing" : '''Marketing

Департамент займається промоцією можливостей, що пропонує AIESEC, розвитком партнерств з різними медіа. У цьому семестрі департамент формує одну команду: 

1⃣ University Relations team - команда, яка займається встановленням та підтримкою комунікації з установами в університетах на кшталт Студради, рекламою/промоцією можливостей від AIESEC.
(На фото віцепрезидентка департаменту Даша)''' ,
                                                "Partnership Development & Alumni Relations" : '''Partnership Development & Alumni Relations

Департамент розвитку партнерств і зв'язків з випускниками займається пошуком нових спонсорів/партнерів проєктів та підтримкою комунікації з наявними. Важливою частиною діяльності департаменту є також взаємодія й підтримка зв'язків з випускниками організації.
Набір нових учасників у департамент не відбувається.
(На фото віцепрезидентка департаменту Катя)''' ,
                                                "Public Relations" : '''Public Relations

Департамент зв'язків з громадскістю займається організацією різноманітних заходів для молоді.
Детальніше про заходи можна прочитати у секції "Про AIESEC".
Набір нових учасників у департамент не відбувається.
(На фото віцепрезидентка департаменту Діана)''' ,   
                                                "Talent Management" : '''Talent Management 

Департамент займається процесом відбору нових учасників організації та менеджментом дійсних членів організації, щоб їхній досвід в AIESEC відбувався якомога продуктивніше й комфортніше.
Набір у департамент не відбувається.
(На фото віцепрезидентка департаменту Юля)''' ,
                                                "Finance" : '''Finance

Департамент фінансів координує кошти організації, займається ризик-менеджментом та контролює його втілення, а також стежить за веденням належної документації усіма департаментами.
Набір до департаменту Фінансів наразі не відбувається
(На фото віцепрезидент департаменту Рауф)''' ,
                                                "Назад" : "До попереднього розділу" }, 
                            "AIESEC culture" : '''✨AIESEC Culture✨
Культура організації - як видима, так і невидима, складається з кількох важливих частин, про які ти можеш дізнатись нижче: 

✨AIESEC essence✨ Це цінності, переконання, глобальна мета організації, які поділяють та підтримують усі учасники AIESEC. Зокрема, "we strive to achieve peace & fulfillment of humankind potential". Під миром розуміється як врегулювання конфліктів, так і досягнення внутрішньої гармонії з собою. AIESEC прагне до світу, у якому люди можуть вільно досягти свого бачення миру, поважаючи при цьому точку зору інших, та бути найкращою версією самих себе. Окрім того, ми вважаємо лідерство ключем до досягнення своїх цілей і якістю, яку може розвинути кожен.

✨Merch✨ Важливий елемент нашої видимої культури, завдяки якому учасники можуть помітити одне одного у натовпі, або просто отримувати задоволення, маючи з собою згадки про AIESEC - це стікери, браслетики, футболки, шопери тощо. Їх можна придбати за бажанням, виграти в одній з активностей або отримати в подарунок від тімлідера своєї команди. Багато команд навіть друкують власні унікальні футболки.

✨Roll calls✨ AIESEC ще й любить потанцювати у перервах між зустрічами, на конференціях і просто на вулиці! Осередок кожної країни сам ставить танець і обирає для нього музику. А наші улюблені roll calls можна переглянути за посиланнями нижче:

📎https://youtu.be/ULVKTNlFMsw
📎 https://youtu.be/ng_NyqWCMsU
📎https://youtu.be/DDaYz4w9mIA''' ,
                            "Заходи" : {
                                                "Local Induction Conference" : '''Перша подія, до якої ти приєднуєшся як учасник організації - це Local induction conference, де учасники знайомляться зі своєю новою командою та її лідером, дізнається більше про організацію, її цінності та принцип роботи. Кілька годин на конференції відчуваються як кілька хвилин, люди надихають, а знання, з якими звідти виходиш, допомагають у подальшій роботі 🔥''',
                                                "New Horizons" : '''Національна конференція, яка збирає учасників AIESEC з усіх міст України. Саме на ній можна побачити масштаби організації, познайомитись з неймовірно цікавими та близькими за духом людьми, і провести продуктивні та веселі дні разом!''' ,
                                                "BDSM day" : '''Business, Development, Sales and Marketing day - це подія, на якій можна дізнатися нову та унікальну інформацію про маркетинг, співпрацю з клієнтами, особистий бренд і багато іншого!

Професійні поради від досвідчених спікерів, історії з власного досвіду  - ось, що треба для вдалого та продуктивного дня!''' ,
                                                "Kyiv Congress" : '''Kyiv Congress

Дводенна конференція осередку AIESEC у Києві відбувається раз на пів року. На ній усі учасники організації можуть перезнайомитись, якщо ще не встигли цього зробити, провести два дні у насиченій атмосфері, адже час сесій на різні теми розписаний похвилинно, запалити увечері під час dance battle, або ж познайомитись з секретним гостем, який буде супроводжувати вечірні та ранкові збори, ділитись інсайтами та своїм шляхом в організації! 

Серед тем, які учасники можуть обговорити на сесіях з запрошеними спікерами (Наприклад, цьогоріч один з них - директор філії Coca-Cola HBC) і нашими віцепрезидентами, були найрізноманітніші: 

🔹 Як надихати інших і самого себе?
🔹 Як знайти внутрішню гармонію?
🔹 Як правильно менеджити свій час?
🔹 Хто такий лідер і чи справді ними народжуються?

І це навіть не половина! Дізнатися більше про секрети і фішки Kyiv Congress та відчути його дух можна лише побувавши там 🤫''' ,
                                                "AIESEC Family Day" : '''AIESEC family day

Це неформальна подія, на якій збираються всі члени київського осередку і проводять разом час, грають у різні ігри, спілкуються, діляться думками та переживаннями, а також влаштовують справжнє Stand up show, де виступити може кожен. Family day - це завжди фаново, цікаво та атмосферно 🎉🤩''' ,
                                                "World's largest lesson" : '''Ініціатива WLL, що проходить кілька разів на рік, має на меті ознайомити з цілями сталого розвитку від ООН якомога більше людей у всьому світі.

Амбасадори ініціативи - це молоді люди віком 16-30 років, які проводять уроки для школярів про Цілі сталого розвитку. Минулого року, наприклад, темою була ціль #13 - Пом'якшення наслідків зміни клімату.

Брати участь у WLL можуть не лише учасники організації, а й усі охочі!''',
                                                "Career Start" : '''@career_start_kyiv

Конференція про можливості роботи і саморозвитку для молоді, на якій учасники мають змогу запитати спікерів-представників успішних компаній все, що їх цікавить, отримати дозу натхнення та поради про збереження ментального здоров'я у робочій рутині та факторах, що заважають досягти бажаного успіху''',
                                                                                            "Назад" : "До попереднього розділу" ,

                            },
                            "Назад" : "До попереднього розділу"
                            },
                             
            "Вступ до організації" : {
                            "Етапи відбору" : {
                                                "AIESEC зустріч" : "Протягом AIESEC зустрічей ти матимеш змогу поспілкуватись з представниками організації, дізнатись більше про організацію та її діяльність, та взяти участь у вирішенні цікавих кейсів. Приходь на зустріч у хорошому настрої та готуйся бути активним!\U0001f609" ,
                                                "Інтерв'ю" : "Інтерв'ю проводять лідери команд і департаментів. Це такі ж проактивні студенти, як і ти, тому у спілкуванні з ними немає нічого страшного\U0001f495 \n " ,
                                                "Тестове завдання" : '''Тестове завдання - етап, на якому ти зможеш відчути себе учасником організації і спробувати виконати типові для нас завдання.

Вмикай свою креативність та навички швидкого вирішення проблем!''' ,
                                                "Назад" : "До попереднього розділу" 

                            },
                            "Розвиток з AIESEC" : {
                                                "Marketing" : '''Використовуй свою творчість та аналітичні навички для створення стратегічних кампаній для залучення молоді до наших стажувань. Ти будеш аналізувати ринок конкурентів та винаходити ідеї для залучення більшої кількості молоді країни до розвитку лідерства.

Навички, які ти можеш отримати: управління брендом, аналіз даних, комунікації, графічний дизайн

Можливі обов'язки:
- Створення промо контенту
- Спілкування з медіапартнерами
- Пошук нових каналів для промо
- Презентація можливостей AIESEC на заходах або в університетах''' ,
                                                "Sales" : '''Працюючи в AIESEC, ти будеш домовлятися з різними компаніями та організаціями про партнерство.

Навички, які ти можеш отримати: ділове листування, ведення переговорів, критичне мислення, Time Management.

Можливі обов'язки:
- Пошук, контактування та зустрічі з потенційними партнерами (компанії або школи)
- Сервісинг партнерів нових та вже існуючих
- Забезпечення виконання стандартів під час реалізації проєктів''' ,
                                                "Customer Experience" : '''Допомагай молоді отримати незабутній досвід від участі у програмах стажувань AIESEC. Ти будеш працювати з іноземними осередками AIESEC та розвивати лідерський потенціал в учасниках стажувань як у своєму місті так і за кордоном.

Навички, які ти можеш отримати: досвід роботи в Customer Service, досвід проектного менеджменту, вміння вести переговори, англійська мова.

Можливі обов'язки:
- Відбір стажерів на професійні проєкти
- Кооперації з закордонними локальними комітетами 
- Підтримка стажерів впродовж реалізації проєктів
- Забезпечення виконання стандартів стажування та збір необхідних документів для стажерів
- Організація активностей для іноземних стажерів в Києві поза їхньою діяльністю на проєктах
- Робота з людьми зацікавленими в стажуванні
- Пошук проєктів для людей''' ,
                                                "Project Management" : '''Працюючи в команді проєкту стажувань ти займатимешся створенням ідеї проекту, його активностей та залученням до нього учасників.

Навички, які ти можеш отримати: проєктний менеджмент, ризик-менеджмент, Time Management, організаційні навички.''' ,
                                                "Leadership" : '''Ми віримо, що лідерство може бути розвинене у будь-кому. Приєднавшись до нас, ти отримаєш шанс розвинути ці лідерські якості у своєму ж місті.

✔️ В AIESEC перед тобою постане завдання вести команду, надаючи практичний досвід, який навчить тебе надихати і розширювати можливості інших.
✔️ Ти будеш мати проєкти та завдання, які вимагатимуть мислити поза межами звичного, ризикувати та, зрештою, орієнтуватися на вирішення викликів.
✔️ Ти станеш громадянином світу та приєднаєшся до спільноти молоді, яка несе відповідальність за покращення світу спільними зусиллями.
✔️ Завдяки досвіду, який ти набуваєш в організації, ти стаєш самосвідомим та починаєш розуміти свої цінності та пристрасті.''' ,
                                                "Кар'єра" : '''AIESEC пропонує своїм учасникам стрімкий, насичений, та челенджовий розвиток. Щосеместру/щороку можна подаватись на позиції вищої ланки, або тієї ж самої, в залежності від того, що тобі подобається і де ти хочеш розвиватись. 

1⃣ Щойно ти приєднуєшся до організації, маєш позицію member. Мембери об'єднані у команди і мають лідера, який є членом AIESEC більше одного семестра. Це твій ментор, керівник і просто друг - все пояснить і розкаже, поділиться досвідом і радітиме твоїм успіхам. Мемберський досвід відкриває двері у наступні позиції, на які можна потрапити лише через внутрішній відбір

2⃣ Returned membership. Ти вже побув мембером, хочеш лишитись в організації, але не відчуваєш достатньо сил, аби подаватися на вищі позиції? Тоді повторне мемберство для тебе. Протягом ще одного семестру ти працюватимеш у команді таких ж учасників і матимеш лідера команди. Зазвичай відбір проводиться у команду рекрутменту (набір нових учасників). Це теж дуже важливий крок, який радять пройти всі, хто мав змогу бути повторним мембером, він приносить свій унікальний досвід і можливості

3⃣ Middle management. З вищою позицією приходить і вища відповідальність - учасники середньої ланки мають більше зустрічей між собою, власні обов'язки та більший спектр роботи. Можна бути координатором (працюєш сам, без команди, маєш власне поле діяльності. Але ти не один - регулярні зустрічі з іншими учасниками Middle management, та своїм лідером - віцепрезидентом. Інша позиція - лідер команди: під його наглядом будуть нові учасники, які приходять після набору, і вони разом працюють над вирішенням завдань. 

4⃣ Віцепрезидент. Передостання ланка учасників організації. Тепер під твоїм керівництвом один з департаментів, а до обов'язків входитимуть: розробка стратегій розвитку, підготовка зустрічей зі своїми учасниками, моніторинг всіх процесів роботи. Термін виконання обов'язків - 1 рік. 

5⃣ Президент Локального комітету - найвища позиція в осередку. Протягом року ти будеш відповідальний(а) за роботу всього AIESEC у Києві, стежитимеш за функціонуванням департаментів, і матимеш багато обов'язків для виконання.

Незважаючи на таку структуру, ти можеш вільно спілкуватись з учасниками вищої ланки, ставити питання, жартувати тощо. Але не забувай про людську взаємоповагу, яка має існувати у будь-яких стосунках.''',
                                                "Назад" : "До попереднього розділу" ,
                                                
                            },
                            "Назад" : "До попереднього розділу"
                           
            }, 
            "FAQ" : {
                            "Що таке AIESEC?" : "AIESEC - це міжнародна молодіжна організація, яка займається розвитком лідерства в молоді через організацію волонтерських та професійних стажувань, конференцій та проектів для молоді.",
                            "Що я буду робити в AIESEC?" : "Що саме ти будеш робити залежить від того, в яку команду ти потрапиш. Загалом ми займаємося організацією стажувань в Україні для іноземних волонтерів, допомагаємо українській молоді отримати якісний досвід на наших стажуаннях за кордоном, організовуємо локальні івенти для молоді. На АЙСЕК-зустрічі дізнаєшся більше про нашу діяльність.",
                            "Як ви відбираєте людей в організацію?" : "У нас є декілька етапів відбору до AIESEC. Перший з них - це зустріч з представниками АЙСЕК, розповідаємо про організацію, далі ми пропонуємо вирішити кейс (певну ситуацію, яка може статися з членом організації). Після цього ми запрошуємо кандидатів на інтерв'ю. Наступним етапом є виконання тестових завдань, що дають змогу спробувати зробити те, чим займаються деякі команди в нашій організації.",
                            "Навіщо такий відбір у волонтерську організацію?" : "Ми хочемо впевнитись, що цінності людини сходяться з цінностями організації, що їй буде цікаво отримати лідерський досвід в AIESEC, та переконатись, що вона має правильні очікування щодо членства в AIESEC.",
                            "До яких AIESEC проектів я можу доєднатись?" : "У нас є проекти, пов'язані з організацією волонтерських або професійних стажувань, продажами, організацією конференцій для молоді. Приходь на AIESEC зустріч, зможеш дізнатись більше. А поки можеш переглянути в які команди ми зараз набираємо людей і чим вони будут займатись.",
                            "Як поїхати на стажування? / Чи поїду я на стажування?" : "Якщо ти заповнив заявку з метою податися на професійне/волонтерське/вчительське стажування, повідом свої контакти @aiesec_manager, і ми передамо їх менеджеру, відповідальному за стажування.",
                            "Я залишив заявку, коли мені зателефонують?" : "Якщо ти заповнив заявку, то можеш чекати дзвінка протягом 3 годин: ми зателефонуємо, щоб її підтвердити і дізнатись про тебе трохи більше. Якщо раптом тобі не зателефонували або ти помітив кілька пропущених, напиши нам на сторінку @aiesec_manager і повідом про це.",
                            "Я не можу прийти на AIESEC зустріч, можна її пропустити?" : "AIESEC зустріч - це важливий етап відбору, і пропустити його не можна. Вони відбуватимуться кілька разів, тому ми впевнені, що зможемо запропонувати зручний для тебе час.",
                            "Я з іншого міста. Чи візьмуть мене в Київський осередок?" : "Пам'ятай про те, що організація проводить регулярні офлайн зустрічі, на яких треба бути присутнім, а волонтерство в деяких департаментах передбачає постійне перебування в Києві.",
                            "Назад" : "До попереднього розділу"
            }, 
            "Дізнатися більше" : '''Додаткову інформацію про організацію AIESEC у Києві та новини можна знайти за посиланнями: 
📌Сайт: aiesec.ua
📌IG: @aiesecinukraine
📌FB: https://www.facebook.com/AIESECinUkraine/ - AIESEC Ukraine''',
            "Написати нам" : '''З будь-якими питаннями стосовно відбору в AIESEC можеш звернутись до нас у телеграмі: @aiesec_manager''' ,
            "Тест на сумісність" : "Наскільки ти та AIESEC хороша пара? Пройди тест та дізнайся!(Всього 15 питань)\nПитання №1\nТобі більше 20?" }


def send_media(chat_id, files):
    media = []
    for file in files:
        fi = open(file, "rb")
        media.append(InputMediaPhoto(fi))
    bot.send_media_group(chat_id, media)


#стартовая кнопка+приветствие
@bot.message_handler(commands=['start'])
def start_command(message):
    markup = types.ReplyKeyboardMarkup()
    gen1buttons = list(buttons.keys())
    for i in range(len(gen1buttons)): 
        markup.row(gen1buttons[i])

    img = open('images/start1.jpg', 'rb') 
    bot.send_photo(message.chat.id, img, caption='''Привіт! Тебе вітає бот міжнародної молодіжної організації \"AIESEC\" \
у Києві! Щоб дізнатися про нас більше, скористайся кнопками в меню.''', reply_markup=markup)
    bot.register_next_step_handler(message, navigation_step_gen1)
#стартовая кнопка конец

#кнопка департаменты
def departments_aiesec_step(message):
    buttons3gen_dict = buttons["Про AIESEC"]["Департаменти"]
    buttons3gen_keys = list(buttons3gen_dict.keys())
    buttons3gen_value = list(buttons3gen_dict.values())
    
    pivot = message.text

    if pivot == buttons3gen_keys[0]:
        img = open('images/ogv.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[0])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[1]:
        img = open('images/ogt.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[1])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[2]:
        img = open('images/igv.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[2])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[3]:
        img = open('images/igta.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[3])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[4]:
        img = open('images/mkt.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[4])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[5]:
        img = open('images/pd.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[5])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[6]:
        img = open('images/pr1.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[6])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[7]:
        img = open('images/tm.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[7])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[8]:
        img = open('images/fin.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[8])
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons3gen_keys[9]:
        back_dict = buttons["Про AIESEC"]
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons3gen_value[9], reply_markup=markup)
        bot.register_next_step_handler(message, about_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, departments_aiesec_step)
#кнопка департаменты конец


#кнопка мероприятия
def events_aiesec_step(message):
    buttons3gen_dict = buttons["Про AIESEC"]["Заходи"]
    buttons3gen_keys = list(buttons3gen_dict.keys())
    buttons3gen_value = list(buttons3gen_dict.values())
    pivot = message.text

    if pivot == buttons3gen_keys[0]:
        img = open('images/lic.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption=buttons3gen_value[0])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[1]:
        files = ["images/nh1.jpg", "images/nh2.jpg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons3gen_value[1])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[2]:
        files = ["images/bdsma.jpg", "images/bdsmb.jpg", "images/bdsmc.jpg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons3gen_value[2])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[3]:
        files = ["images/kyivcong1.jpg", "images/kyivcong2.jpg", "images/kyivcong3.jpg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons3gen_value[3])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[4]:
        files = ["images/family1.jpg", "images/family2.jpg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons3gen_value[4])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[5]:
        bot.reply_to(message, buttons3gen_value[5])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[6]:
        files = ["images/cs1.jpeg", "images/cs2.jpeg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons3gen_value[6])
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons3gen_keys[7]:
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons3gen_value[7], reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, departments_aiesec_step)
#кнопка мероприятия конец

#кнопка про айсек
def about_aiesec_step(message):
    buttons2gen_dict = buttons["Про AIESEC"]
    buttons2gen_keys = list(buttons2gen_dict.keys())
    buttons2gen_value = list(buttons2gen_dict.values())
    pivot = message.text

    if pivot == buttons2gen_keys[0]:
        buttons3gen_dict = buttons2gen_dict[pivot]
        buttons3gen_keys = list(buttons3gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(buttons3gen_keys)): 
            markup.row(buttons3gen_keys[i])
        
        img = open('images/departments.jpg', 'rb') 
        bot.send_photo(message.chat.id, img, caption="Departments", reply_markup=markup)

        #bot.reply_to(message, "Departments", reply_markup=markup)
        bot.register_next_step_handler(message, departments_aiesec_step)
    elif pivot == buttons2gen_keys[1]:
        files = ["images/culture.jpg", "images/culture1.jpg", "images/culture2.jpg"]
        send_media(message.chat.id, files)
        bot.reply_to(message, buttons2gen_value[1])
        bot.register_next_step_handler(message, about_aiesec_step)
    elif pivot == buttons2gen_keys[2]:
        buttons3gen_dict = buttons2gen_dict[pivot]
        buttons3gen_keys = list(buttons3gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(buttons3gen_keys)): 
            markup.row(buttons3gen_keys[i])
        bot.reply_to(message, "Заходи", reply_markup=markup)
        bot.register_next_step_handler(message, events_aiesec_step)
    elif pivot == buttons2gen_keys[3]:
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons2gen_value[3], reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, about_aiesec_step)
#кнопка про айсек конец


def selection_aiesec_step(message):
    buttons3gen_dict = buttons["Вступ до організації"]["Етапи відбору"]
    buttons3gen_keys = list(buttons3gen_dict.keys())
    buttons3gen_value = list(buttons3gen_dict.values())
    pivot = message.text
    
    if pivot == buttons3gen_keys[0]:
        bot.reply_to(message, buttons3gen_value[0])
        bot.register_next_step_handler(message, selection_aiesec_step)
    elif pivot == buttons3gen_keys[1]:
        bot.reply_to(message, buttons3gen_value[1])
        bot.register_next_step_handler(message, selection_aiesec_step)
    elif pivot == buttons3gen_keys[2]:
        bot.reply_to(message, buttons3gen_value[2])
        bot.register_next_step_handler(message, selection_aiesec_step)
    elif pivot == buttons3gen_keys[3]:
        back_dict = buttons["Вступ до організації"]
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons3gen_value[3], reply_markup=markup)
        bot.register_next_step_handler(message, join_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, join_aiesec_step)   



def development_aiesec_step(message):
    buttons3gen_dict = buttons["Вступ до організації"]["Розвиток з AIESEC"]
    buttons3gen_keys = list(buttons3gen_dict.keys())
    buttons3gen_value = list(buttons3gen_dict.values())
    pivot = message.text
    
    if pivot == buttons3gen_keys[0]:
        bot.reply_to(message, buttons3gen_value[0])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[1]:
        bot.reply_to(message, buttons3gen_value[1])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[2]:
        bot.reply_to(message, buttons3gen_value[2])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[3]:
        bot.reply_to(message, buttons3gen_value[3])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[4]:
        bot.reply_to(message, buttons3gen_value[4])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[5]:
        bot.reply_to(message, buttons3gen_value[5])
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons3gen_keys[6]:
        back_dict = buttons["Вступ до організації"]
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons3gen_value[6], reply_markup=markup)
        bot.register_next_step_handler(message, join_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, join_aiesec_step)   



#кнопка вступить в айсек
def join_aiesec_step(message):
    buttons2gen_dict = buttons["Вступ до організації"]
    buttons2gen_keys = list(buttons2gen_dict.keys())
    buttons2gen_value = list(buttons2gen_dict.values())
    pivot = message.text

    if pivot == buttons2gen_keys[0]:
        buttons3gen_dict = buttons2gen_dict[pivot]
        buttons3gen_keys = list(buttons3gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(0, len(buttons3gen_keys), 2): 
            markup.row(buttons3gen_keys[i], buttons3gen_keys[i+1])
        bot.reply_to(message, "Етапи відбору", reply_markup=markup)
        bot.register_next_step_handler(message, selection_aiesec_step)
    elif pivot == buttons2gen_keys[1]:
        buttons3gen_dict = buttons2gen_dict[pivot]
        buttons3gen_keys = list(buttons3gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(0, len(buttons3gen_keys)-1, 2): 
            markup.row(buttons3gen_keys[i], buttons3gen_keys[i+1])
        markup.row(buttons3gen_keys[6])
        bot.reply_to(message, "Розвиток з AIESEC", reply_markup=markup)
        bot.register_next_step_handler(message, development_aiesec_step)
    elif pivot == buttons2gen_keys[2]:
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons2gen_value[2], reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, join_aiesec_step)
#кнопка вступить в айсек конец   


game_counter = 0

def game_q15_aiesec_step(message):
    global game_counter
    pivot = message.text
    answer = "pass"
    if pivot == "Так":
        game_counter += 1
        if game_counter <= 5:
            answer = "Ми думаємо, що інші проєкти, організації та ініціативи зможуть розкрити твій потенціал краще, ніж це зробить AIESEC. "
        elif game_counter <= 10:
            answer = "Ти на правильному шляху, друже! Якщо продовжиш у тому ж дусі, AIESEC буде радий бачити тебе як активного учасника організації!"
        else:
            answer = "Маєш класний результат! Сподіваємось, що у процесі відбору ти зможеш показати себе з найкращої сторони і звати себе AIESECером вже дуже скоро!"
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, answer, reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "Ні":
        if game_counter <= 5:
            answer = "Ми думаємо, що інші проєкти, організації та ініціативи зможуть розкрити твій потенціал краще, ніж це зробить AIESEC. "
        elif game_counter <= 10:
            answer = "Ти на правильному шляху, друже! Якщо продовжиш у тому ж дусі, AIESEC буде радий бачити тебе як активного учасника організації!"
        else:
            answer = "Маєш класний результат! Сподіваємось, що у процесі відбору ти зможеш показати себе з найкращої сторони і звати себе AIESECером вже дуже скоро!"
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, answer, reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q15_aiesec_step)



def game_q14_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №14\nЛюбиш працювати в команді?")
        bot.register_next_step_handler(message, game_q15_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №14\nЛюбиш працювати в команді?")
        bot.register_next_step_handler(message, game_q15_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q14_aiesec_step)


def game_q13_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №13\nЦікавишся культурою інших країн?")
        bot.register_next_step_handler(message, game_q14_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №13\nЦікавишся культурою інших країн?")
        bot.register_next_step_handler(message, game_q14_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q13_aiesec_step)


def game_q12_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №12\nМаєш бажання брати участь у AIESEC-ініціативах?")
        bot.register_next_step_handler(message, game_q13_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №12\nМаєш бажання брати участь у AIESEC-ініціативах?")
        bot.register_next_step_handler(message, game_q13_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q12_aiesec_step)



def game_q11_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №11\nЛюбиш розвиватися?")
        bot.register_next_step_handler(message, game_q12_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №11\nЛюбиш розвиватися?")
        bot.register_next_step_handler(message, game_q12_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q11_aiesec_step)



def game_q10_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №10\nПрагнеш покращувати світ?")
        bot.register_next_step_handler(message, game_q11_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №10\nПрагнеш покращувати світ?")
        bot.register_next_step_handler(message, game_q11_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q10_aiesec_step)


def game_q9_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №9\nМаєш час на регулярні зустрічі щопонеділка та додаткові зустрічі протягом тижня?")
        bot.register_next_step_handler(message, game_q10_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №9\nМаєш час на регулярні зустрічі щопонеділка та додаткові зустрічі протягом тижня?")
        bot.register_next_step_handler(message, game_q10_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q9_aiesec_step)



def game_q8_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №8\nШвидко вчишся?")
        bot.register_next_step_handler(message, game_q9_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №8\nШвидко вчишся?")
        bot.register_next_step_handler(message, game_q9_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q8_aiesec_step)


def game_q7_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №7\nХочеш покращити навички комунікації?")
        bot.register_next_step_handler(message, game_q8_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №7\nХочеш покращити навички комунікації?")
        bot.register_next_step_handler(message, game_q8_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q7_aiesec_step)



def game_q6_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №6\nТи активний?")
        bot.register_next_step_handler(message, game_q7_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №6\nТи активний?")
        bot.register_next_step_handler(message, game_q7_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q6_aiesec_step)


def game_q5_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        bot.reply_to(message, "Питання №5\nПеребуваєш у Києві постійно?")
        bot.register_next_step_handler(message, game_q6_aiesec_step)
    elif pivot == "Ні":
        game_counter += 1
        bot.reply_to(message, "Питання №5\nПеребуваєш у Києві постійно?")
        bot.register_next_step_handler(message, game_q6_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q5_aiesec_step)


def game_q4_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        bot.reply_to(message, "Питання №5\nМаєш волонтерський досвід?")
        bot.register_next_step_handler(message, game_q5_aiesec_step)
    elif pivot == "Ні":
        game_counter += 1
        bot.reply_to(message, "Питання №5\nМаєш волонтерський досвід?")
        bot.register_next_step_handler(message, game_q5_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q4_aiesec_step)


def game_q3_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №4\nМаєш фултайм роботу?")
        bot.register_next_step_handler(message, game_q4_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №4\nМаєш фултайм роботу?")
        bot.register_next_step_handler(message, game_q4_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q3_aiesec_step)


def game_q2_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        game_counter += 1
        bot.reply_to(message, "Питання №3\nМаєш рівень англійської A2 або вищий?")
        bot.register_next_step_handler(message, game_q3_aiesec_step)
    elif pivot == "Ні":
        bot.reply_to(message, "Питання №3\nМаєш рівень англійської A2 або вищий?")
        bot.register_next_step_handler(message, game_q3_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q2_aiesec_step)


def game_q1_aiesec_step(message):
    global game_counter
    pivot = message.text
    if pivot == "Так":
        bot.reply_to(message, "Питання №2\nГотовий волонтерити в AIESEC 10+ годин на тиждень?")
        bot.register_next_step_handler(message, game_q2_aiesec_step)
    elif pivot == "Ні":
        game_counter += 1
        bot.reply_to(message, "Питання №2\nГотовий волонтерити в AIESEC 10+ годин на тиждень?")
        bot.register_next_step_handler(message, game_q2_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, game_q1_aiesec_step)


def faq_aiesec_step(message):
    buttons3gen_dict = buttons["FAQ"]
    buttons3gen_keys = list(buttons3gen_dict.keys())
    buttons3gen_value = list(buttons3gen_dict.values())
    
    pivot = message.text

    if pivot == buttons3gen_keys[0]: 
        bot.reply_to(message, buttons3gen_value[0])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[1]:
        bot.reply_to(message, buttons3gen_value[1])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[2]:
        bot.reply_to(message, buttons3gen_value[2])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[3]:
        bot.reply_to(message, buttons3gen_value[3])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[4]:
        bot.reply_to(message, buttons3gen_value[4])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[5]:
        bot.reply_to(message, buttons3gen_value[5])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[6]:
        bot.reply_to(message, buttons3gen_value[6])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[7]:
        bot.reply_to(message, buttons3gen_value[7])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[8]:
        bot.reply_to(message, buttons3gen_value[8])
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons3gen_keys[10]:
        back_dict = buttons
        back_keys = list(back_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(back_keys)): 
            markup.row(back_keys[i])
        bot.reply_to(message, buttons3gen_value[10], reply_markup=markup)
        bot.register_next_step_handler(message, navigation_step_gen1)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
        bot.register_next_step_handler(message, departments_aiesec_step)



#кнопка меню первое
def navigation_step_gen1(message):
    global game_counter
    buttons1gen_keys = list(buttons.keys())
    buttons1gen_value = list(buttons.values())
    pivot = message.text

    if pivot == buttons1gen_keys[0]:
        buttons2gen_dict = buttons[pivot]
        buttons2gen_keys = list(buttons2gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(buttons2gen_keys)): 
            markup.row(buttons2gen_keys[i])
        text = '''Розвиваємо лідерство з 1948

AIESEC - це глобальна молодіжна платформа для розвитку лідерського потенціалу через міжнародні стажування та волонтерські можливості.

AIESEC - це:

✅ 120+ Країн і територій
✅ 400+ Учасників в Україні
✅ 7000+ Партнерів по всьому світу
✅ 30000+ Стажувань цілорічно'''
        bot.reply_to(message, text, reply_markup=markup)
        bot.register_next_step_handler(message, about_aiesec_step)
    elif pivot == buttons1gen_keys[1]:
        buttons2gen_dict = buttons[pivot]
        buttons2gen_keys = list(buttons2gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(buttons2gen_keys)): 
            markup.row(buttons2gen_keys[i])
        text = '''Вступ до організації: 

У цьому розділі ти знайдеш інформацію про етапи відбору та навички, які можна прокачати разом з AIESEC'''
        bot.reply_to(message, text, reply_markup=markup)
        bot.register_next_step_handler(message, join_aiesec_step)
    elif pivot == buttons1gen_keys[2]:
        buttons2gen_dict = buttons[pivot]
        buttons2gen_keys = list(buttons2gen_dict.keys())
        markup = types.ReplyKeyboardMarkup()
        for i in range(len(buttons2gen_keys)): 
            markup.row(buttons2gen_keys[i])
        text = '''FAQ

У цій секції ти знайдеш відповіді на найпопулярніші питання стосовно AIESEC та вступу до організації'''
        bot.reply_to(message, text, reply_markup=markup)
        bot.register_next_step_handler(message, faq_aiesec_step)
    elif pivot == buttons1gen_keys[3]:
        bot.reply_to(message, buttons1gen_value[3])
        bot.register_next_step_handler(message,navigation_step_gen1)
    elif pivot == buttons1gen_keys[4]: 
        bot.reply_to(message, buttons1gen_value[4])
        bot.register_next_step_handler(message,navigation_step_gen1)
    elif pivot == buttons1gen_keys[5]:
        markup = types.ReplyKeyboardMarkup() 
        markup.row("Так", "Ні")
        game_counter = 0
        bot.reply_to(message, buttons1gen_value[5], reply_markup=markup)
        bot.register_next_step_handler(message, game_q1_aiesec_step)
    elif pivot == "/start":
        start_command(message)
    else:
        bot.reply_to(message, "Користуйся, будь ласка, кнопками.")
#кнопка меню первое конец

bot.polling(none_stop=True, interval=0)
